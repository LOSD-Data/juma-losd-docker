package ie.tcd.kdeg.r2rmleditor.components;

import org.apache.tapestry5.annotations.Import;

/**
 * Layout component for pages of application portal.
 */
@Import(stylesheet = "context:css/layout.css")
public class LayoutLogin {
	

}
