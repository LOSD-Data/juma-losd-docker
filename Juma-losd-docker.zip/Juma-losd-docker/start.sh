#!/bin/bash

chmod -R 777 /var/www/html/juma-api/temp
service apache2 start
service mysql start
cd /juma/juma-uplift-master
screen -S juma -d -m mvn jetty:run -Djetty.port=8888
read
